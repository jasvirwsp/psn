<?php
header("Location: rad_tools.php");

?>