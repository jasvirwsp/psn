-- Generation time: Thu, 24 Nov 2022 11:30:01 +0100
-- Host: localhost
-- DB name: psn
/*!40030 SET NAMES UTF8 */;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `booking_desk_id` text NOT NULL,
  `booking_desk_count` text NOT NULL,
  `booking_visit_time` text NOT NULL,
  `booking_user_id` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `booking_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4;

INSERT INTO `booking` VALUES ('42','1','','08:00','15','2022-11-24 11:27:04','2022-11-24 11:27:04','15'),
('43','1','','08:05','15','2022-11-24 11:27:09','2022-11-24 11:27:09','15'),
('44','1','','08:05','15','2022-11-24 11:27:38','2022-11-24 11:27:38','15'); 


DROP TABLE IF EXISTS `branding`;
CREATE TABLE `branding` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `branding_title` text NOT NULL,
  `branding_logo` text NOT NULL,
  `branding_color_scheme` text NOT NULL,
  `branding_footer` text NOT NULL,
  `branding_logo_width_lg` text NOT NULL,
  `branding_logo_width_sm` text NOT NULL,
  `branding_insert_author` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `branding` VALUES ('2','Paesano Orders Panel','','dark','Project by WSP','50','50','15','2019-10-19 12:51:10','2022-11-21 11:26:37'); 


DROP TABLE IF EXISTS `desk`;
CREATE TABLE `desk` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `desk_size` text NOT NULL,
  `desk_time` text NOT NULL,
  `desk_count` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `desk_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `desk` VALUES ('1','2_persons','5','5','2022-11-24 8:24:00','2022-11-24 11:14:42','15'),
('2','4_persons','10','25','2022-11-24 8:24:25','2022-11-24 8:24:25','15'),
('3','8_persons','15','10','2022-11-24 8:24:39','2022-11-24 10:04:36','15'); 


DROP TABLE IF EXISTS `email`;
CREATE TABLE `email` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `email_from` text NOT NULL,
  `email_to` text NOT NULL,
  `email_subject` text NOT NULL,
  `email_status` text NOT NULL,
  `email_body` text NOT NULL,
  `email_attachments` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `email_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `file_upload`;
CREATE TABLE `file_upload` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `file_upload_identifier` text NOT NULL,
  `file_upload_file_name` text NOT NULL,
  `file_upload_insert_author` text NOT NULL,
  `file_upload_input_name` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `file_upload` VALUES ('1','upload_5fdf5ba14cbf97062','upload_5fdf5ba14cbf97062_logo.png','15','branding_logo','2020-12-20 15:11:45',''); 


DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `setting_name` text NOT NULL,
  `setting_value` text NOT NULL,
  `setting_category` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `setting_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `template`;
CREATE TABLE `template` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `template_mail_title` text NOT NULL,
  `template_mail_content` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `template_insert_author` text NOT NULL,
  `template_editor_content` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `trash`;
CREATE TABLE `trash` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `trash_record_type` text NOT NULL,
  `trash_record_id` text NOT NULL,
  `trash_record_data` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `trash_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO `trash` VALUES ('1','users','16','a:24:{s:2:\"id\";s:2:\"16\";s:4:\"user\";s:6:\"tetete\";s:11:\"user_author\";s:2:\"16\";s:5:\"email\";s:11:\"tete@gm.com\";s:8:\"password\";s:60:\"$2y$10$9Trw8.uhxO9KnnKSUhP6VePdIyhUuXpa1.3FGREs.vVhEtEUUwuOW\";s:4:\"role\";s:7:\"teacher\";s:12:\"display_name\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"auth_token\";s:0:\"\";s:11:\"reset_token\";s:0:\"\";s:12:\"access_token\";s:0:\"\";s:3:\"otp\";s:0:\"\";s:8:\"verified\";s:1:\"0\";s:23:\"email_verification_code\";s:0:\"\";s:10:\"created_at\";s:19:\"2022-03-01 21:42:05\";s:9:\"user_name\";s:3:\"tet\";s:15:\"user_contact_no\";s:0:\"\";s:12:\"user_address\";s:0:\"\";s:11:\"user_status\";s:6:\"active\";s:12:\"date_created\";s:19:\"2022-03-01 17:12:05\";s:12:\"date_updated\";s:19:\"2022-03-01 17:12:05\";s:11:\"user_school\";s:0:\"\";s:19:\"user_school_address\";s:0:\"\";s:22:\"user_school_contact_no\";s:0:\"\";}','2022-03-01 17:12:48','2022-03-01 17:12:48','15'),
('2','audio','1','a:8:{s:9:\"record_id\";s:1:\"1\";s:11:\"audio_title\";s:26:\"Studey Trick for UPSC Exam\";s:16:\"audio_youtube_id\";s:11:\"L8_YWGnFWIM\";s:10:\"audio_file\";s:3:\"dsa\";s:12:\"audio_status\";s:6:\"active\";s:12:\"date_created\";s:19:\"2022-03-01 16:05:07\";s:12:\"date_updated\";s:19:\"2022-03-01 16:14:23\";s:19:\"audio_insert_author\";s:2:\"15\";}','2022-03-22 9:35:20','2022-03-22 9:35:20','15'),
('3','users','16','a:24:{s:2:\"id\";s:2:\"16\";s:4:\"user\";s:20:\"ullamco_voluptatem_c\";s:11:\"user_author\";s:2:\"16\";s:5:\"email\";s:24:\"hixotelyt@mailinator.com\";s:8:\"password\";s:60:\"$2y$10$lkZCgfsTjFwufpxJTNvl0uLNU7qOf6LmYc4rcLWdA09ei682pWd5K\";s:4:\"role\";s:4:\"user\";s:12:\"display_name\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"auth_token\";s:0:\"\";s:11:\"reset_token\";s:0:\"\";s:12:\"access_token\";s:0:\"\";s:3:\"otp\";s:0:\"\";s:8:\"verified\";s:1:\"0\";s:23:\"email_verification_code\";s:0:\"\";s:10:\"created_at\";s:19:\"2022-07-07 21:17:42\";s:9:\"user_name\";s:8:\"qahasofo\";s:15:\"user_contact_no\";s:2:\"16\";s:12:\"user_address\";s:20:\"Minima quae incididu\";s:11:\"user_status\";s:8:\"disabled\";s:12:\"date_created\";s:19:\"2022-07-07 17:47:42\";s:12:\"date_updated\";s:19:\"2022-07-07 17:47:42\";s:11:\"user_school\";s:0:\"\";s:19:\"user_school_address\";s:0:\"\";s:22:\"user_school_contact_no\";s:0:\"\";}','2022-07-07 17:47:50','2022-07-07 17:47:50','15'),
('4','booking','6','a:8:{s:9:\"record_id\";s:1:\"6\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:37:11\";s:12:\"date_updated\";s:18:\"2022-11-24 9:37:11\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('5','booking','5','a:8:{s:9:\"record_id\";s:1:\"5\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:34:22\";s:12:\"date_updated\";s:18:\"2022-11-24 9:34:22\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('6','booking','4','a:8:{s:9:\"record_id\";s:1:\"4\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:33:59\";s:12:\"date_updated\";s:18:\"2022-11-24 9:33:59\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('7','booking','3','a:8:{s:9:\"record_id\";s:1:\"3\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:13:19\";s:12:\"date_updated\";s:18:\"2022-11-24 9:13:19\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('8','booking','2','a:8:{s:9:\"record_id\";s:1:\"2\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:2:\"12\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:10:18\";s:12:\"date_updated\";s:18:\"2022-11-24 9:10:18\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('9','booking','1','a:8:{s:9:\"record_id\";s:1:\"1\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:1:\"2\";s:18:\"booking_visit_time\";s:4:\"8:15\";s:15:\"booking_user_id\";s:1:\"2\";s:12:\"date_created\";s:18:\"2022-11-24 8:34:55\";s:12:\"date_updated\";s:18:\"2022-11-24 8:35:03\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('10','booking','17','a:8:{s:9:\"record_id\";s:2:\"17\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 10:21:11\";s:12:\"date_updated\";s:19:\"2022-11-24 10:21:11\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('11','booking','16','a:8:{s:9:\"record_id\";s:2:\"16\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:9:\"123213213\";s:12:\"date_created\";s:19:\"2022-11-24 10:18:33\";s:12:\"date_updated\";s:19:\"2022-11-24 10:18:33\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('12','booking','15','a:8:{s:9:\"record_id\";s:2:\"15\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:16:40\";s:12:\"date_updated\";s:19:\"2022-11-24 10:16:40\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('13','booking','14','a:8:{s:9:\"record_id\";s:2:\"14\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:15:35\";s:12:\"date_updated\";s:19:\"2022-11-24 10:15:35\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('14','booking','13','a:8:{s:9:\"record_id\";s:2:\"13\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:05:50\";s:12:\"date_updated\";s:19:\"2022-11-24 10:05:50\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('15','booking','12','a:8:{s:9:\"record_id\";s:2:\"12\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:5:\"45345\";s:12:\"date_created\";s:19:\"2022-11-24 10:04:46\";s:12:\"date_updated\";s:19:\"2022-11-24 10:04:46\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('16','booking','11','a:8:{s:9:\"record_id\";s:2:\"11\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:03:24\";s:12:\"date_updated\";s:19:\"2022-11-24 10:03:24\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('17','booking','10','a:8:{s:9:\"record_id\";s:2:\"10\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:02:23\";s:12:\"date_updated\";s:19:\"2022-11-24 10:02:23\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('18','booking','9','a:8:{s:9:\"record_id\";s:1:\"9\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:2:\"13\";s:12:\"date_created\";s:19:\"2022-11-24 10:01:23\";s:12:\"date_updated\";s:19:\"2022-11-24 10:01:23\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('19','booking','8','a:8:{s:9:\"record_id\";s:1:\"8\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:1:\"2\";s:12:\"date_created\";s:18:\"2022-11-24 9:58:49\";s:12:\"date_updated\";s:18:\"2022-11-24 9:58:49\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('20','booking','7','a:8:{s:9:\"record_id\";s:1:\"7\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:1:\"1\";s:12:\"date_created\";s:18:\"2022-11-24 9:58:37\";s:12:\"date_updated\";s:18:\"2022-11-24 9:58:37\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('21','booking','21','a:8:{s:9:\"record_id\";s:2:\"21\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"00:09\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:10:59\";s:12:\"date_updated\";s:19:\"2022-11-24 11:10:59\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('22','booking','20','a:8:{s:9:\"record_id\";s:2:\"20\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:10:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:10:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('23','booking','19','a:8:{s:9:\"record_id\";s:2:\"19\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:10:07\";s:12:\"date_updated\";s:19:\"2022-11-24 11:10:07\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('24','booking','18','a:8:{s:9:\"record_id\";s:2:\"18\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:09:52\";s:12:\"date_updated\";s:19:\"2022-11-24 11:09:52\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('25','booking','25','a:8:{s:9:\"record_id\";s:2:\"25\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:17:36\";s:12:\"date_updated\";s:19:\"2022-11-24 11:17:36\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('26','booking','24','a:8:{s:9:\"record_id\";s:2:\"24\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:14:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:14:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('27','booking','23','a:8:{s:9:\"record_id\";s:2:\"23\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:14:48\";s:12:\"date_updated\";s:19:\"2022-11-24 11:14:48\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('28','booking','22','a:8:{s:9:\"record_id\";s:2:\"22\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:14:29\";s:12:\"date_updated\";s:19:\"2022-11-24 11:14:29\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('29','booking','28','a:8:{s:9:\"record_id\";s:2:\"28\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:19:37\";s:12:\"date_updated\";s:19:\"2022-11-24 11:19:37\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:20:52','2022-11-24 11:20:52','15'),
('30','booking','27','a:8:{s:9:\"record_id\";s:2:\"27\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:19:29\";s:12:\"date_updated\";s:19:\"2022-11-24 11:19:29\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:20:52','2022-11-24 11:20:52','15'),
('31','booking','26','a:8:{s:9:\"record_id\";s:2:\"26\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:19:21\";s:12:\"date_updated\";s:19:\"2022-11-24 11:19:21\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:20:52','2022-11-24 11:20:52','15'),
('32','booking','31','a:8:{s:9:\"record_id\";s:2:\"31\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:21:32\";s:12:\"date_updated\";s:19:\"2022-11-24 11:21:32\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:35','2022-11-24 11:22:35','15'),
('33','booking','30','a:8:{s:9:\"record_id\";s:2:\"30\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:21:14\";s:12:\"date_updated\";s:19:\"2022-11-24 11:21:14\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:35','2022-11-24 11:22:35','15'),
('34','booking','29','a:8:{s:9:\"record_id\";s:2:\"29\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:20:58\";s:12:\"date_updated\";s:19:\"2022-11-24 11:20:58\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:35','2022-11-24 11:22:35','15'),
('35','booking','33','a:8:{s:9:\"record_id\";s:2:\"33\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:10\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:22:38\";s:12:\"date_updated\";s:19:\"2022-11-24 11:22:38\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:51','2022-11-24 11:22:51','15'),
('36','booking','32','a:8:{s:9:\"record_id\";s:2:\"32\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:21:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:21:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:51','2022-11-24 11:22:51','15'),
('37','booking','36','a:8:{s:9:\"record_id\";s:2:\"36\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:23:09\";s:12:\"date_updated\";s:19:\"2022-11-24 11:23:09\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:25','2022-11-24 11:24:25','15'),
('38','booking','35','a:8:{s:9:\"record_id\";s:2:\"35\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:23:03\";s:12:\"date_updated\";s:19:\"2022-11-24 11:23:03\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:25','2022-11-24 11:24:25','15'),
('39','booking','34','a:8:{s:9:\"record_id\";s:2:\"34\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:22:58\";s:12:\"date_updated\";s:19:\"2022-11-24 11:22:58\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:25','2022-11-24 11:24:25','15'),
('40','booking','37','a:8:{s:9:\"record_id\";s:2:\"37\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:23:34\";s:12:\"date_updated\";s:19:\"2022-11-24 11:23:34\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:39','2022-11-24 11:24:39','15'),
('41','booking','41','a:8:{s:9:\"record_id\";s:2:\"41\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:25:51\";s:12:\"date_updated\";s:19:\"2022-11-24 11:25:51\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('42','booking','40','a:8:{s:9:\"record_id\";s:2:\"40\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:25:25\";s:12:\"date_updated\";s:19:\"2022-11-24 11:25:25\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('43','booking','39','a:8:{s:9:\"record_id\";s:2:\"39\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:25:04\";s:12:\"date_updated\";s:19:\"2022-11-24 11:25:04\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('44','booking','38','a:8:{s:9:\"record_id\";s:2:\"38\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:24:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:24:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'); 


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `user_author` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `display_name` text NOT NULL,
  `rights` text NOT NULL,
  `auth_token` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `access_token` varchar(255) NOT NULL COMMENT 'For mobile API',
  `otp` text NOT NULL,
  `verified` int(2) NOT NULL,
  `email_verification_code` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_name` text NOT NULL,
  `user_contact_no` text NOT NULL,
  `user_address` text NOT NULL,
  `user_status` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `user_school` text NOT NULL,
  `user_school_address` text NOT NULL,
  `user_school_contact_no` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ('15','admin','1','ghulianisikh@gmail.com','$2y$10$RuGKQg6z8yXTfGgpnox.nu1EoH80L3cR3ZPxHZGSLgAiMhv/K9X1m','admin','Jasminder','','wsp_637f171a0d39192188','','wsp_5d9503aadb182791392','','0','','2019-02-12 22:51:16','Admin','','','','2019-02-12 22:51:16','2020-12-20 15:12:01','','',''),
('16','','0','manavsingh839@gmail.com','$2y$10$/aiHYS0M.26cwLlieO3U0uv/z7B..LqRXXhLmAnI6PNTQmuqSvOWi','user','','','wsp_637ca1ef76a8b301110','707459','wsp_637ca1ef76a99490925','','0','','2022-11-21 16:43:50','Manav Singh','9914649789','','','2022-11-21 11:13:50','2022-11-21 11:13:50','','',''); 




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

