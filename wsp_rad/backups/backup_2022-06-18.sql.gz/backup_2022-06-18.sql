-- Generation time: Sat, 18 Jun 2022 14:18:33 +0200
-- Host: localhost
-- DB name: rad_v15
/*!40030 SET NAMES UTF8 */;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `branding`;
CREATE TABLE `branding` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `branding_title` text NOT NULL,
  `branding_logo` text NOT NULL,
  `branding_color_scheme` text NOT NULL,
  `branding_footer` text NOT NULL,
  `branding_logo_width_lg` text NOT NULL,
  `branding_logo_width_sm` text NOT NULL,
  `branding_insert_author` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `branding` VALUES ('2','WSP','','dark','Project by WSP','50','50','15','2019-10-19 12:51:10','2022-03-01 15:27:33'); 


DROP TABLE IF EXISTS `email`;
CREATE TABLE `email` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `email_from` text NOT NULL,
  `email_to` text NOT NULL,
  `email_subject` text NOT NULL,
  `email_status` text NOT NULL,
  `email_body` text NOT NULL,
  `email_attachments` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `email_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `file_upload`;
CREATE TABLE `file_upload` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `file_upload_identifier` text NOT NULL,
  `file_upload_file_name` text NOT NULL,
  `file_upload_insert_author` text NOT NULL,
  `file_upload_input_name` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `file_upload` VALUES ('1','upload_5fdf5ba14cbf97062','upload_5fdf5ba14cbf97062_logo.png','15','branding_logo','2020-12-20 15:11:45',''); 


DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `setting_name` text NOT NULL,
  `setting_value` text NOT NULL,
  `setting_category` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `setting_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `template`;
CREATE TABLE `template` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `template_mail_title` text NOT NULL,
  `template_mail_content` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `template_insert_author` text NOT NULL,
  `template_editor_content` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `trash`;
CREATE TABLE `trash` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `trash_record_type` text NOT NULL,
  `trash_record_id` text NOT NULL,
  `trash_record_data` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `trash_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `trash` VALUES ('1','users','16','a:24:{s:2:\"id\";s:2:\"16\";s:4:\"user\";s:6:\"tetete\";s:11:\"user_author\";s:2:\"16\";s:5:\"email\";s:11:\"tete@gm.com\";s:8:\"password\";s:60:\"$2y$10$9Trw8.uhxO9KnnKSUhP6VePdIyhUuXpa1.3FGREs.vVhEtEUUwuOW\";s:4:\"role\";s:7:\"teacher\";s:12:\"display_name\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"auth_token\";s:0:\"\";s:11:\"reset_token\";s:0:\"\";s:12:\"access_token\";s:0:\"\";s:3:\"otp\";s:0:\"\";s:8:\"verified\";s:1:\"0\";s:23:\"email_verification_code\";s:0:\"\";s:10:\"created_at\";s:19:\"2022-03-01 21:42:05\";s:9:\"user_name\";s:3:\"tet\";s:15:\"user_contact_no\";s:0:\"\";s:12:\"user_address\";s:0:\"\";s:11:\"user_status\";s:6:\"active\";s:12:\"date_created\";s:19:\"2022-03-01 17:12:05\";s:12:\"date_updated\";s:19:\"2022-03-01 17:12:05\";s:11:\"user_school\";s:0:\"\";s:19:\"user_school_address\";s:0:\"\";s:22:\"user_school_contact_no\";s:0:\"\";}','2022-03-01 17:12:48','2022-03-01 17:12:48','15'),
('2','audio','1','a:8:{s:9:\"record_id\";s:1:\"1\";s:11:\"audio_title\";s:26:\"Studey Trick for UPSC Exam\";s:16:\"audio_youtube_id\";s:11:\"L8_YWGnFWIM\";s:10:\"audio_file\";s:3:\"dsa\";s:12:\"audio_status\";s:6:\"active\";s:12:\"date_created\";s:19:\"2022-03-01 16:05:07\";s:12:\"date_updated\";s:19:\"2022-03-01 16:14:23\";s:19:\"audio_insert_author\";s:2:\"15\";}','2022-03-22 9:35:20','2022-03-22 9:35:20','15'); 


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `user_author` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `display_name` text NOT NULL,
  `rights` text NOT NULL,
  `auth_token` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `access_token` varchar(255) NOT NULL COMMENT 'For mobile API',
  `otp` text NOT NULL,
  `verified` int(2) NOT NULL,
  `email_verification_code` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_name` text NOT NULL,
  `user_contact_no` text NOT NULL,
  `user_address` text NOT NULL,
  `user_status` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `user_school` text NOT NULL,
  `user_school_address` text NOT NULL,
  `user_school_contact_no` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ('15','admin','1','ghulianisikh@gmail.com','$2y$10$RuGKQg6z8yXTfGgpnox.nu1EoH80L3cR3ZPxHZGSLgAiMhv/K9X1m','admin','Jasminder','','wsp_62adc29629264536026','','wsp_5d9503aadb182791392','','0','','2019-02-12 22:51:16','Admin','','','','2019-02-12 22:51:16','2020-12-20 15:12:01','','',''); 




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

